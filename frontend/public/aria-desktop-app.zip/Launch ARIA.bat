@echo off
title ARIA Agent Console
echo Launching ARIA in standalone desktop window...
start msedge --app=https://aria-2-f3kq.onrender.com || start chrome --app=https://aria-2-f3kq.onrender.com || start explorer https://aria-2-f3kq.onrender.com
exit
